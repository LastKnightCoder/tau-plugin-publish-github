// packages/plugins/src/ids.ts
function assertLocalId(value) {
  if (typeof value !== "string" || !/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,127}$/.test(value)) {
    throw new Error("\u63D2\u4EF6\u6807\u8BC6\u5FC5\u987B\u4E3A 1 \u81F3 128 \u4F4D\u5B57\u6BCD\u3001\u6570\u5B57\u3001\u70B9\u3001\u6A2A\u7EBF\u6216\u4E0B\u5212\u7EBF");
  }
}

// packages/plugins/src/version.ts
function parseVersion(value) {
  const match = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/.exec(
    value
  );
  if (!match) throw new Error(`\u7248\u672C\u53F7\u65E0\u6548\uFF1A${value}`);
  const pre = match[4]?.split(".") ?? [];
  if (pre.some((part) => /^\d+$/.test(part) && part.length > 1 && part.startsWith("0")))
    throw new Error(`\u7248\u672C\u53F7\u65E0\u6548\uFF1A${value}`);
  return { core: match.slice(1, 4), pre };
}
function comparePluginVersions(left, right) {
  const a = parseVersion(left);
  const b = parseVersion(right);
  const numeric = (x, y) => BigInt(x) === BigInt(y) ? 0 : BigInt(x) > BigInt(y) ? 1 : -1;
  for (let index = 0; index < 3; index++) {
    const result = numeric(a.core[index], b.core[index]);
    if (result) return result;
  }
  if (!a.pre.length || !b.pre.length)
    return a.pre.length === b.pre.length ? 0 : a.pre.length ? -1 : 1;
  for (let index = 0; index < Math.max(a.pre.length, b.pre.length); index++) {
    const x = a.pre[index], y = b.pre[index];
    if (x === void 0 || y === void 0) return x === void 0 ? -1 : 1;
    if (x === y) continue;
    const nx = /^\d+$/.test(x), ny = /^\d+$/.test(y);
    return nx && ny ? numeric(x, y) : nx !== ny ? nx ? -1 : 1 : x > y ? 1 : -1;
  }
  return 0;
}

// packages/plugins/src/categories.ts
var PLUGIN_CATEGORIES = [
  { id: "sync", label: "\u540C\u6B65" },
  { id: "upload", label: "\u8D44\u6E90\u4E0A\u4F20" },
  { id: "editor", label: "\u7F16\u8F91\u5668" },
  { id: "whiteboard", label: "\u767D\u677F" },
  { id: "blog-template", label: "\u535A\u5BA2\u6A21\u677F" },
  { id: "blog-publish", label: "\u535A\u5BA2\u53D1\u5E03" },
  { id: "ai", label: "AI" },
  { id: "voice", label: "\u8BED\u97F3" },
  { id: "page", label: "\u9875\u9762" }
];
var PLUGIN_KEYWORD_LIMIT = 5;
var PLUGIN_KEYWORD_MAX_LENGTH = 20;
var categoryIds = new Set(PLUGIN_CATEGORIES.map((item) => item.id));
var isPluginCategory = (value) => typeof value === "string" && categoryIds.has(value);
function readCatalogFields(item, strict) {
  const fail = (message) => {
    if (strict) throw new Error(message);
  };
  const list = (value, name) => {
    if (value === void 0) return [];
    if (Array.isArray(value)) return value;
    fail(`${name} \u5FC5\u987B\u662F\u6570\u7EC4`);
    return [];
  };
  const categories = [];
  for (const value of list(item.categories, "categories")) {
    if (!isPluginCategory(value)) fail(`\u672A\u77E5\u63D2\u4EF6\u5206\u7C7B\uFF1A${String(value)}`);
    else if (!categories.includes(value)) categories.push(value);
  }
  const keywords = [];
  for (const value of list(item.keywords, "keywords")) {
    const keyword = typeof value === "string" ? value.trim() : "";
    if (!keyword || keyword.length > PLUGIN_KEYWORD_MAX_LENGTH)
      fail(`\u5173\u952E\u8BCD\u5FC5\u987B\u4E3A 1 \u81F3 ${PLUGIN_KEYWORD_MAX_LENGTH} \u5B57`);
    else if (!keywords.includes(keyword)) keywords.push(keyword);
  }
  if (keywords.length > PLUGIN_KEYWORD_LIMIT) {
    fail(`\u5173\u952E\u8BCD\u6700\u591A ${PLUGIN_KEYWORD_LIMIT} \u4E2A`);
    keywords.length = PLUGIN_KEYWORD_LIMIT;
  }
  return {
    ...categories.length ? { categories: Object.freeze(categories) } : {},
    ...keywords.length ? { keywords: Object.freeze(keywords) } : {}
  };
}

// packages/plugins/src/package.ts
var PLUGIN_SHARED_MODULES = [
  "@tau/plugins",
  "@tau/plugins/whiteboard",
  "@tau/plugins/sync",
  "@tau/ui",
  "react",
  "react-dom",
  "react-dom/client",
  "react/jsx-runtime",
  "react/jsx-dev-runtime"
];
function validatePluginManifest(value, options = {}) {
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw new Error("\u63D2\u4EF6\u6E05\u5355\u5FC5\u987B\u662F\u5BF9\u8C61");
  const item = value;
  if (item.formatVersion !== 1 || item.apiVersion !== 1 || item.platform !== "desktop" || item.format !== "cjs")
    throw new Error("\u63D2\u4EF6\u5305\u683C\u5F0F\u3001API \u7248\u672C\u6216\u5E73\u53F0\u4E0D\u517C\u5BB9");
  if (typeof item.id !== "string") throw new Error("\u63D2\u4EF6 ID \u65E0\u6548");
  assertLocalId(item.id);
  if (typeof item.name !== "string" || !item.name.trim() || typeof item.version !== "string" || !/^\d+\.\d+\.\d+(?:-[\w.-]+)?$/.test(item.version))
    throw new Error("\u63D2\u4EF6\u540D\u79F0\u6216\u7248\u672C\u65E0\u6548");
  const file = (input, extension) => {
    if (typeof input !== "string" || !/^[\w./-]+$/.test(input) || input.split("/").some((part) => !part || part === "." || part === "..") || !input.endsWith(extension))
      throw new Error("\u63D2\u4EF6\u5165\u53E3\u6216\u6837\u5F0F\u8DEF\u5F84\u65E0\u6548");
    return input;
  };
  const main = file(item.main, ".js");
  if (item.sync !== void 0) throw new Error("Node\u540C\u6B65\u5165\u53E3\u5DF2\u505C\u7528\uFF0C\u8BF7\u66F4\u65B0\u63D2\u4EF6");
  if (item.minAppVersion !== void 0) {
    if (typeof item.minAppVersion !== "string") throw new Error("\u6700\u4F4E\u5BA2\u6237\u7AEF\u7248\u672C\u65E0\u6548");
    comparePluginVersions(item.minAppVersion, item.minAppVersion);
  }
  const styles = item.styles === void 0 ? void 0 : file(item.styles, ".css");
  if (item.editor !== void 0 && item.editor !== true) throw new Error("editor \u53EA\u80FD\u58F0\u660E\u4E3A true");
  if (item.whiteboard !== void 0 && item.whiteboard !== true)
    throw new Error("whiteboard \u53EA\u80FD\u58F0\u660E\u4E3A true");
  const catalog = readCatalogFields(item, options.strict === true);
  const integrity = {};
  for (const name of [main, ...styles ? [styles] : []]) {
    const hash = item.integrity && typeof item.integrity === "object" ? item.integrity[name] : void 0;
    if (typeof hash !== "string" || !/^[a-f0-9]{64}$/.test(hash))
      throw new Error("\u63D2\u4EF6\u4EA7\u7269\u7F3A\u5C11\u6709\u6548\u7684\u5B8C\u6574\u6027\u6458\u8981");
    integrity[name] = hash;
  }
  return Object.freeze({
    formatVersion: 1,
    id: item.id,
    name: item.name,
    version: item.version,
    ...typeof item.minAppVersion === "string" ? { minAppVersion: item.minAppVersion } : {},
    apiVersion: 1,
    platform: "desktop",
    format: "cjs",
    main,
    ...item.editor === true ? { editor: true } : {},
    ...item.whiteboard === true ? { whiteboard: true } : {},
    ...catalog,
    integrity: Object.freeze(integrity),
    ...styles === void 0 ? {} : { styles }
  });
}

// packages/plugins/src/rendering.ts
var PLUGIN_RENDER_VERSION = 1;
function evaluatePluginPackage(artifact, modules) {
  const manifest = validatePluginManifest(artifact.manifest);
  const module = { exports: {} };
  new Function(
    "require",
    "module",
    "exports",
    '"use strict";\n' + artifact.code + `
//# sourceURL=tau-plugin://${manifest.id}/${manifest.version}/main.js`
  )(
    (id) => {
      if (!PLUGIN_SHARED_MODULES.some((name) => name === id) || !Object.hasOwn(modules, id))
        throw new Error(`\u63D2\u4EF6\u4F7F\u7528\u4E86\u672A\u63D0\u4F9B\u7684\u5BBF\u4E3B\u6A21\u5757\uFF1A${id}`);
      return modules[id];
    },
    module,
    module.exports
  );
  return validatePluginDefinition(manifest, module.exports.default);
}
function validatePluginDefinition(manifest, definition) {
  if (!definition || typeof definition.create !== "function" || definition.id !== manifest.id || definition.name !== manifest.name || definition.version !== manifest.version || definition.apiVersion !== manifest.apiVersion)
    throw new Error("\u63D2\u4EF6\u5165\u53E3\u5B9A\u4E49\u4E0E\u6E05\u5355\u4E0D\u4E00\u81F4");
  if (Boolean(definition.editorExtensions?.length) !== Boolean(manifest.editor))
    throw new Error("\u7F16\u8F91\u5668\u8D21\u732E\u5FC5\u987B\u4E0E manifest.editor \u58F0\u660E\u4E00\u81F4");
  if (Boolean(definition.whiteboardExtensions?.length) !== Boolean(manifest.whiteboard))
    throw new Error("\u767D\u677F\u8D21\u732E\u5FC5\u987B\u4E0E manifest.whiteboard \u58F0\u660E\u4E00\u81F4");
  getPluginWhiteboardTypes(definition);
  if (definition.editorCodecs?.length && !manifest.editor)
    throw new Error("Markdown codec \u5FC5\u987B\u968F\u7F16\u8F91\u5668\u8D21\u732E\u58F0\u660E");
  if (manifest.editor) {
    const types = getPluginNodeTypes(definition);
    if (definition.editorCodecs?.some((codec) => !types.includes(codec.type)))
      throw new Error("\u63D2\u4EF6 codec \u53EA\u80FD\u58F0\u660E\u672C\u63D2\u4EF6\u63D0\u4F9B\u7684\u8282\u70B9\u7C7B\u578B");
  }
  return definition;
}
function getPluginNodeTypes(definition) {
  const types = [];
  for (const extension of definition.editorExtensions ?? []) {
    if ("plugins" in extension) throw new Error("\u7F16\u8F91\u5668\u63D2\u4EF6\u4E0D\u652F\u6301\u539F\u59CB Slate \u5305\u88C5\u5668");
    for (const element of extension.elements ?? []) {
      if (!element.type || types.includes(element.type))
        throw new Error(`\u63D2\u4EF6\u8282\u70B9\u7C7B\u578B\u4E3A\u7A7A\u6216\u91CD\u590D\uFF1A${element.type}`);
      types.push(element.type);
    }
  }
  if (definition.editorExtensions?.length && !types.length)
    throw new Error("\u7F16\u8F91\u5668\u63D2\u4EF6\u5FC5\u987B\u58F0\u660E\u8282\u70B9\u7C7B\u578B");
  const htmlTypes = /* @__PURE__ */ new Set();
  for (const extension of definition.editorExtensions ?? []) {
    for (const source of extension.styleSources ?? [])
      if (!types.includes(source.type) || !source.field || !["html", "tsx"].includes(source.language))
        throw new Error("\u63D2\u4EF6\u6837\u5F0F\u6E90\u7801\u5FC5\u987B\u58F0\u660E\u672C\u63D2\u4EF6\u7684\u8282\u70B9\u5B57\u6BB5\u548C\u8BED\u8A00");
    for (const serializer of extension.htmlSerializers ?? []) {
      if (!types.includes(serializer.type) || htmlTypes.has(serializer.type) || typeof serializer.toHtml !== "function")
        throw new Error("\u63D2\u4EF6 HTML \u5BFC\u51FA\u7C7B\u578B\u91CD\u590D\u6216\u4E0D\u5C5E\u4E8E\u672C\u63D2\u4EF6");
      htmlTypes.add(serializer.type);
    }
  }
  return types;
}
function getPluginWhiteboardTypes(definition) {
  if (definition.whiteboardExtensions !== void 0 && !Array.isArray(definition.whiteboardExtensions))
    throw new Error("\u767D\u677F\u6269\u5C55\u58F0\u660E\u5FC5\u987B\u4E3A\u6570\u7EC4");
  const types = /* @__PURE__ */ new Set();
  const extensions = /* @__PURE__ */ new Set();
  for (const extension of definition.whiteboardExtensions ?? []) {
    if (!extension || typeof extension.id !== "string" || extension.apiVersion !== 1 || typeof extension.create !== "function" || extension.id !== definition.id && !extension.id.startsWith(`${definition.id}.`) || extensions.has(extension.id))
      throw new Error("\u767D\u677F\u6269\u5C55\u8EAB\u4EFD\u91CD\u590D\u6216\u4E0D\u5C5E\u4E8E\u5F53\u524D\u63D2\u4EF6");
    extensions.add(extension.id);
    if (!Array.isArray(extension.elements) || !extension.elements.length)
      throw new Error("\u767D\u677F\u63D2\u4EF6\u5FC5\u987B\u58F0\u660E\u9759\u6001\u5143\u7D20");
    for (const element of extension.elements) {
      if (!element || typeof element.type !== "string" || !element.type.startsWith(`${definition.id}.`) || types.has(element.type) || typeof element.render !== "function")
        throw new Error("\u767D\u677F\u5143\u7D20\u91CD\u590D\u3001\u7F3A\u5C11\u6E32\u67D3\u6216\u4E0D\u5C5E\u4E8E\u5F53\u524D\u63D2\u4EF6");
      types.add(element.type);
    }
  }
  return [...types];
}
function assertRenderTypes(definition, expected) {
  const actual = getPluginNodeTypes(definition);
  if (actual.length !== expected.length || actual.some((type) => !expected.includes(type)))
    throw new Error("\u53D1\u5E03\u7684\u8282\u70B9\u5F52\u5C5E\u4E0E\u63D2\u4EF6\u5B9A\u4E49\u4E0D\u4E00\u81F4");
}

// packages/plugins/src/publish-artifacts.ts
var PLUGIN_RENDER_VERSION2 = PLUGIN_RENDER_VERSION;
function evaluatePluginPackage2(artifact, modules) {
  return evaluatePluginPackage(artifact, modules);
}
function assertRenderTypes2(definition, types) {
  assertRenderTypes(definition, types);
}
export {
  PLUGIN_RENDER_VERSION2 as PLUGIN_RENDER_VERSION,
  PLUGIN_SHARED_MODULES,
  assertRenderTypes2 as assertRenderTypes,
  evaluatePluginPackage2 as evaluatePluginPackage,
  validatePluginManifest
};
