// packages/plugins/src/publish-client.ts
var DataError = class extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
    this.name = "DataError";
  }
};
function assert(condition, code, message) {
  if (!condition) throw new DataError(code, message);
}
function record(value) {
  return !!value && typeof value === "object" && !Array.isArray(value);
}
function resourceUrl(relative, base) {
  assert(
    typeof relative === "string" && !!relative && !/[\\:%?#]/.test(relative) && relative.split("/").every((part) => part && part !== "." && part !== ".."),
    "INVALID_DATA",
    "\u6570\u636E\u8D44\u6E90\u8DEF\u5F84\u65E0\u6548"
  );
  return new URL(relative, base).href;
}
function cancelled(signal) {
  if (signal?.aborted) throw new DOMException("\u8BFB\u53D6\u5DF2\u53D6\u6D88", "AbortError");
}
async function waitFor(pending, signal) {
  cancelled(signal);
  if (!signal) return pending;
  let abort = () => {
  };
  try {
    return await Promise.race([
      pending,
      new Promise((_resolve, reject) => {
        abort = () => reject(new DOMException("\u8BFB\u53D6\u5DF2\u53D6\u6D88", "AbortError"));
        signal.addEventListener("abort", abort, { once: true });
      })
    ]);
  } finally {
    signal.removeEventListener("abort", abort);
  }
}
function createClient({ manifestUrl }) {
  const origin = new URL(manifestUrl).href;
  const cache = /* @__PURE__ */ new Map();
  let manifestPromise;
  let searchPromise;
  let engine;
  function json(url, expected) {
    assert(/^[a-f0-9]{64}$/.test(expected), "INVALID_DATA", "\u6458\u8981\u683C\u5F0F\u9519\u8BEF");
    const filenameHash = new URL(url).pathname.match(/\.([a-f0-9]{64})\.json$/)?.[1];
    assert(filenameHash === expected, "INTEGRITY_MISMATCH", "\u6587\u4EF6\u540D\u4E0E\u58F0\u660E\u6458\u8981\u4E0D\u4E00\u81F4");
    let pending = cache.get(url);
    if (!pending) {
      pending = (async () => {
        const response = await fetch(url);
        if (!response.ok)
          throw new DataError("RESOURCE_LOAD_FAILED", `HTTP ${response.status}\uFF1A${url}`);
        const bytes = await response.arrayBuffer();
        const digest = [...new Uint8Array(await crypto.subtle.digest("SHA-256", bytes))].map((byte) => byte.toString(16).padStart(2, "0")).join("");
        assert(digest === expected, "INTEGRITY_MISMATCH", `\u8D44\u6E90\u6458\u8981\u9519\u8BEF\uFF1A${url}`);
        try {
          return JSON.parse(new TextDecoder().decode(bytes));
        } catch {
          throw new DataError("INVALID_DATA", `JSON \u65E0\u6548\uFF1A${url}`);
        }
      })().catch((error) => {
        cache.delete(url);
        if (error instanceof DataError) throw error;
        throw new DataError("RESOURCE_LOAD_FAILED", String(error));
      });
      cache.set(url, pending);
    }
    return pending;
  }
  function manifest() {
    if (!manifestPromise) {
      manifestPromise = (async () => {
        const hash = new URL(origin).pathname.match(/site\.([a-f0-9]{64})\.json$/)?.[1];
        assert(hash, "INVALID_DATA", "\u6E05\u5355 URL \u7F3A\u5C11\u6458\u8981");
        const value = await json(origin, hash);
        assert(record(value), "INVALID_DATA", "\u6E05\u5355\u5FC5\u987B\u662F\u5BF9\u8C61");
        assert(value.version === 1, "PROTOCOL_MISMATCH", "\u6570\u636E\u534F\u8BAE\u7248\u672C\u4E0D\u5339\u914D");
        assert(
          record(value.site) && Array.isArray(value.items) && record(value.search),
          "INVALID_DATA",
          "\u6E05\u5355\u5B57\u6BB5\u7F3A\u5931"
        );
        const keys = /* @__PURE__ */ new Set();
        assert(
          typeof value.site.title === "string" && typeof value.site.description === "string" && typeof value.site.basePath === "string",
          "INVALID_DATA",
          "\u7AD9\u70B9\u6570\u636E\u7F3A\u5931"
        );
        for (const item of value.items) {
          assert(
            record(item) && typeof item.key === "string" && typeof item.type === "string",
            "INVALID_DATA",
            "\u6570\u636E\u8EAB\u4EFD\u7F3A\u5931"
          );
          assert(!keys.has(item.key), "INVALID_DATA", "\u6E05\u5355 key \u91CD\u590D");
          assert(
            typeof item.data === "string" && typeof item.integrity === "string",
            "INVALID_DATA",
            "\u6570\u636E\u6587\u4EF6\u5F15\u7528\u7F3A\u5931"
          );
          keys.add(item.key);
          assert(
            ["home", "card", "article", "doc", "quest", "list"].includes(String(item.type)) && typeof item.title === "string",
            "INVALID_DATA",
            "\u6570\u636E\u7C7B\u578B\u6216\u6807\u9898\u65E0\u6548"
          );
          resourceUrl(item.data, origin);
          assert(/^[a-f0-9]{64}$/.test(item.integrity), "INVALID_DATA", "\u6570\u636E\u6458\u8981\u65E0\u6548");
        }
        assert(
          typeof value.search.data === "string" && typeof value.search.integrity === "string",
          "INVALID_DATA",
          "\u7D22\u5F15\u5F15\u7528\u7F3A\u5931"
        );
        resourceUrl(value.search.data, origin);
        assert(
          /^[a-f0-9]{64}$/.test(value.search.integrity),
          "INVALID_DATA",
          "\u7D22\u5F15\u6458\u8981\u65E0\u6548"
        );
        return value;
      })().catch((error) => {
        manifestPromise = void 0;
        cache.delete(origin);
        throw error;
      });
    }
    return manifestPromise;
  }
  function index() {
    if (!searchPromise) {
      searchPromise = (async () => {
        const source = await manifest();
        const url = resourceUrl(source.search.data, origin);
        const value = await json(url, source.search.integrity);
        assert(record(value), "INVALID_DATA", "\u7D22\u5F15\u5FC5\u987B\u662F\u5BF9\u8C61");
        assert(value.version === 1, "PROTOCOL_MISMATCH", "\u7D22\u5F15\u7248\u672C\u4E0D\u5339\u914D");
        assert(Array.isArray(value.documents), "INVALID_DATA", "\u7D22\u5F15\u7F3A\u5C11 documents");
        const seen = /* @__PURE__ */ new Set();
        for (const document of value.documents) {
          assert(
            record(document) && typeof document.key === "string",
            "INVALID_DATA",
            "\u641C\u7D22\u8EAB\u4EFD\u65E0\u6548"
          );
          const item = source.items.find((item2) => item2.key === document.key);
          assert(
            item && item.type === document.type && !seen.has(document.key),
            "INVALID_DATA",
            "\u641C\u7D22 key \u672A\u95ED\u5408\u6216\u91CD\u590D"
          );
          assert(
            ["card", "article", "doc", "quest"].includes(String(document.type)),
            "INVALID_DATA",
            "\u641C\u7D22\u7C7B\u578B\u9519\u8BEF"
          );
          assert(
            ["title", "summary", "content"].every((field) => typeof document[field] === "string"),
            "INVALID_DATA",
            "\u641C\u7D22\u6587\u672C\u7F3A\u5931"
          );
          assert(
            Array.isArray(document.tags) && document.tags.every((tag) => typeof tag === "string"),
            "INVALID_DATA",
            "\u641C\u7D22\u6807\u7B7E\u65E0\u6548"
          );
          seen.add(document.key);
        }
        return value;
      })().catch((error) => {
        searchPromise = void 0;
        if (manifestPromise)
          void manifestPromise.then(
            (source) => cache.delete(resourceUrl(source.search.data, origin)),
            () => void 0
          );
        throw error;
      });
    }
    return searchPromise;
  }
  return {
    async readManifest({ signal } = {}) {
      cancelled(signal);
      return waitFor(manifest(), signal);
    },
    async readData({ key, signal }) {
      cancelled(signal);
      const source = await waitFor(manifest(), signal);
      const item = source.items.find((item2) => item2.key === key);
      assert(item, "DATA_NOT_FOUND", `\u672A\u53D1\u5E03\u5185\u5BB9\uFF1A${key}`);
      const dataUrl = resourceUrl(item.data, origin);
      const value = await waitFor(json(dataUrl, item.integrity), signal);
      assert(
        record(value) && record(value.meta) && record(value.content),
        "INVALID_DATA",
        "\u5185\u5BB9\u7ED3\u6784\u9519\u8BEF"
      );
      assert(value.version === 1, "PROTOCOL_MISMATCH", "\u5185\u5BB9\u534F\u8BAE\u7248\u672C\u4E0D\u5339\u914D");
      assert(
        value.key === key && value.meta.type === item.type && (item.id === void 0 || value.content.id === void 0 || value.content.id === item.id),
        "IDENTITY_MISMATCH",
        "\u5185\u5BB9\u8EAB\u4EFD\u4E0D\u5339\u914D"
      );
      return {
        data: value,
        dataUrl,
        ...source.settings ? { settings: source.settings } : {}
      };
    },
    async search(query, { limit = 12, signal } = {}) {
      cancelled(signal);
      const normalized = query.replace(/\s+/g, " ").trim();
      if (!normalized) return [];
      assert(Number.isInteger(limit) && limit > 0, "INVALID_DATA", "limit \u5FC5\u987B\u662F\u6B63\u6574\u6570");
      const [{ documents }, { default: Fuse }] = await waitFor(
        Promise.all([index(), import("./client/fuse-M2Z6NNAT.js")]),
        signal
      );
      cancelled(signal);
      if (engine?.documents !== documents)
        engine = {
          documents,
          fuse: new Fuse(documents, {
            keys: ["title", "summary", "content", "tags"],
            includeMatches: true,
            threshold: 0.3,
            ignoreLocation: true
          })
        };
      return engine.fuse.search(normalized, { limit }).map(({ item, matches }) => {
        const { content: _content, ...hit } = item;
        const ranges = (matches ?? []).flatMap((match) => {
          if (!match.value || !["title", "summary", "content", "tags"].includes(match.key ?? ""))
            return [];
          return [
            {
              field: match.key,
              text: match.value,
              ranges: match.indices.map(([start, end]) => [start, end + 1])
            }
          ];
        });
        return { ...hit, matches: ranges };
      });
    }
  };
}
export {
  DataError,
  createClient
};
