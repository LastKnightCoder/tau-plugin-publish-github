throw new Error("Tau 插件模块由宿主提供，请在插件构建中设为 external");
