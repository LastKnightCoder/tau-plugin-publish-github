import { type ReactNode } from "react";
export interface FileDropZoneProps {
    /** 同 <input accept> */
    accept?: string;
    /** 单选：只取第一个文件 */
    onFile?: (file: File) => void;
    /** 多选：拖入或选择的全部文件（同时开启文件框多选） */
    onFiles?: (files: File[]) => void;
    disabled?: boolean;
    className?: string;
    children: ReactNode;
}
/** 点击选择或拖入文件的区域；拖入时高亮 */
export declare function FileDropZone({ accept, onFile, onFiles, disabled, className, children, }: FileDropZoneProps): import("react/jsx-runtime").JSX.Element;
