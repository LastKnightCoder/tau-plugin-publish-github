/**
 * 全年活动热力图（圆点）—— 今日页回顾段的自绘图表
 * （圆点、色阶随 scale 递增、周列贴底对齐、hover 呼吸、全宽自适应；
 * 图例含连续活跃天数角标）。
 * 零业务依赖：输入为 {date, count}[] 纯数据；色阶为 accent 的 alpha 派生，随主题换肤。
 */
import { type ReactNode } from "react";
export interface YearHeatmapDay {
    date: string;
    count: number;
}
export declare function YearHeatmap({ days, caption }: {
    days: YearHeatmapDay[];
    caption?: ReactNode;
}): import("react/jsx-runtime").JSX.Element;
