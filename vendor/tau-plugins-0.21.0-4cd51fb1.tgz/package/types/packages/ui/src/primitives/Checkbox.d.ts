/**
 * Checkbox —— 勾选基础件（Input 方案 A「经典描边」语言，mockups/checkbox/，2026-09-19 定稿）。
 *
 * 原生 input[type=checkbox] 承载语义（appearance-none 自绘皮）：label 点击切换、
 * Space 原生支持、读屏语义白送。「浮起物」：16×16 视觉格 surface + line-1，
 * 选中转 accent 实底 + 反色勾（110ms 淡入，唯一的固定反馈——无动效 prop）。
 *
 * 结构铁律：input / 格子 / 勾图标必须在同一层互为兄弟——Tailwind 的 peer-* 变体
 * 只匹配 peer 的后续兄弟（`~ *`），挂在深层后代上会静默失效（勾选后无任何视觉）。
 * 状态语义（与 Input 裁决同源）：
 *  - 命中 24×24（input 绝对定位撑满锚格，宪法下限）；focus-visible 才显 ring
 *    （锚格经 has- 变体响应，因锚是 input 的父级而非兄弟）
 *  - hover 描边加深半档（未选中 ink-3/50 / 选中 accent-hover），聚焦时让位
 *  - indeterminate 半选（accent 实底 + 横线）：DOM 属性驱动，联动逻辑归调用方
 *  - 错误态正源 aria-invalid（未选中 danger；选中/半选保持 accent）；禁用降透明
 */
import { type ComponentProps, type ReactNode } from "react";
export interface CheckboxProps extends Omit<ComponentProps<"input">, "type"> {
    /** 可选：渲染关联 label（点文字切换）；不传则裸勾选框 */
    label?: ReactNode;
    /** 半选视觉态（DOM 属性驱动；点击行为仍由调用方决定全选/清空） */
    indeterminate?: boolean;
}
export declare function Checkbox({ label, indeterminate, className, disabled, ref, ...props }: CheckboxProps): import("react/jsx-runtime").JSX.Element;
