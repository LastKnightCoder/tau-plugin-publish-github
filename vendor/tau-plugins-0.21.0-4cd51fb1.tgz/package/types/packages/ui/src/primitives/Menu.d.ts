/**
 * 菜单基础件：命令、开关、单选组、分隔与子菜单组成的异构浮层。
 * 键盘导航、焦点回收、外点关闭和菜单树互斥由组件内建。
 */
import { type ReactElement, type ReactNode } from "react";
/** 根级：命令项触发后的整树关闭（外点/互斥由 dismiss 层逐层登记承担，D-014） */
export interface MenuRootContextValue {
    closeMenu: () => void;
}
export interface MenuItemProps {
    icon?: ReactNode;
    /** 快捷键提示（展示用；键监听归全局注册表，这里不接线） */
    kbd?: string;
    danger?: boolean;
    disabled?: boolean;
    onSelect?: () => void;
    children: ReactNode;
    className?: string;
}
declare function MenuItem({ icon, kbd, danger, disabled, onSelect, children, className }: MenuItemProps): import("react/jsx-runtime").JSX.Element;
export interface MenuCheckboxItemProps {
    checked?: boolean;
    onCheckedChange?: (checked: boolean) => void;
    icon?: ReactNode;
    kbd?: string;
    disabled?: boolean;
    children: ReactNode;
    className?: string;
}
declare function MenuCheckboxItem({ checked, onCheckedChange, icon, kbd, disabled, children, className, }: MenuCheckboxItemProps): import("react/jsx-runtime").JSX.Element;
export interface MenuRadioGroupProps {
    value?: string;
    onValueChange?: (value: string) => void;
    children: ReactNode;
}
declare function MenuRadioGroup({ value, onValueChange, children }: MenuRadioGroupProps): import("react/jsx-runtime").JSX.Element;
export interface MenuRadioItemProps {
    value: string;
    icon?: ReactNode;
    kbd?: string;
    disabled?: boolean;
    children: ReactNode;
    className?: string;
}
declare function MenuRadioItem({ value, icon, kbd, disabled, children, className }: MenuRadioItemProps): import("react/jsx-runtime").JSX.Element;
export interface MenuSubmenuProps {
    label: ReactNode;
    icon?: ReactNode;
    disabled?: boolean;
    children: ReactNode;
}
declare function MenuSubmenu({ label, icon, disabled, children }: MenuSubmenuProps): import("react/jsx-runtime").JSX.Element;
declare function MenuSeparator(): import("react/jsx-runtime").JSX.Element;
declare function MenuGroup({ children }: {
    children: ReactNode;
}): import("react/jsx-runtime").JSX.Element;
export interface MenuProps {
    /**
     * 触发器（单一元素，克隆注入开合事件 / aria / ref；不强制本组件的按钮样式）。
     * 协议同 Tooltip：元素必须透传 props 与 ref——原生元素或 {...rest} 透传的
     * 组件；不透传的包装组件会吞掉注入，点击无反应。
     */
    trigger: ReactElement;
    children: ReactNode;
    /** 交叉轴对齐：start = 左缘 / end = 右缘对齐触发器 */
    align?: "start" | "end";
    /** 浮层受控（§5.3 契约；样板间常显标本用它） */
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    /** 透传浮层（宽度控制如 w-[280px]） */
    className?: string;
    /** 尽量展开：主层与子层高度上限放到视口高度（默认 300px），只有视口放不下才滚动 */
    fit?: boolean;
}
export declare function Menu({ trigger, children, align, open: openProp, onOpenChange, className, fit, }: MenuProps): import("react/jsx-runtime").JSX.Element;
export declare namespace Menu {
    var Item: typeof MenuItem;
    var CheckboxItem: typeof MenuCheckboxItem;
    var RadioGroup: typeof MenuRadioGroup;
    var RadioItem: typeof MenuRadioItem;
    var Submenu: typeof MenuSubmenu;
    var Separator: typeof MenuSeparator;
    var Group: typeof MenuGroup;
}
export interface ContextMenuProps {
    /** 被包裹的区域（区域内在任意处右键弹出菜单） */
    children: ReactNode;
    /** 菜单内容（与 Menu 的 children 同构） */
    content: ReactNode;
    className?: string;
}
export declare function ContextMenu({ children, content, className }: ContextMenuProps): import("react/jsx-runtime").JSX.Element;
export {};
