import { type ReactNode } from "react";
export interface TabItem<K extends string = string> {
    key: K;
    label: ReactNode;
    children: ReactNode;
}
export interface TabsProps<K extends string = string> {
    items: readonly TabItem<K>[];
    activeKey?: K;
    defaultActiveKey?: K;
    onChange?: (key: K) => void;
    /** 标签居中（默认左对齐） */
    centered?: boolean;
    className?: string;
}
/** 下划线式标签页（与 desktop 设置页同一视觉语言）；方向键在标签间移动 */
export declare function Tabs<K extends string = string>({ items, activeKey: activeKeyProp, defaultActiveKey, onChange, centered, className, }: TabsProps<K>): import("react/jsx-runtime").JSX.Element;
