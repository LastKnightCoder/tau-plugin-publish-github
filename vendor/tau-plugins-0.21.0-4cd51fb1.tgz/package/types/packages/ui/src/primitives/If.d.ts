import React from "react";
interface IIfProps {
    condition: boolean;
}
declare const If: React.FC<React.PropsWithChildren<IIfProps>>;
export default If;
