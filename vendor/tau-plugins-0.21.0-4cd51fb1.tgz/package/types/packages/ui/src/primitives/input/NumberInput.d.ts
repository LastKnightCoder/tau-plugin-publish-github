/**
 * NumberInput —— 数值输入（Input 同形 + beforeinput 事前拦截，mockups/input/ 方案 A）。
 *
 * 值契约：value: number | null（string 草稿只在内部，blur/Enter 归一化提交）。
 *
 * 事前拦截（2026-09-19 用户裁决，取代「事后标红」）：
 *  - 原生 beforeinput 监听用「当前值 + 选区 + 待插入文本」预判结果，不合数字格式直接
 *    preventDefault——键盘输入 / 粘贴 / 拖放的非数字内容根本进不来
 *  - 粘贴含杂质不生硬拒绝：先清洗（"¥1,200" → "1200"）再以 setRangeText 插入，
 *    实在洗不干净才放弃（静默，无红字）
 *  - 合法中间态（"5." / "-."）放行，否则没法输小数；IME 组合期间放行
 *    （insertCompositionText 不可取消），compositionend 兜底清洗
 *  - blur / Enter 归一化："5." → 5、".5" → 0.5、去多余前导零
 */
import { type ComponentProps } from "react";
export interface NumberInputProps extends Omit<ComponentProps<"input">, "value" | "defaultValue" | "onChange" | "type" | "size"> {
    value: number | null;
    onValueChange: (value: number | null) => void;
    size?: "sm" | "md";
    /** 形态透传 Input：bare 为无皮行内形态（无边框背景与 focus 反馈，归宿主） */
    variant?: "outlined" | "bare";
    /** 透传 Input：外框容器类名（定宽写这里；className 落到内部 <input>） */
    wrapperClassName?: string;
}
export declare function NumberInput({ value, onValueChange, variant, onBlur, onKeyDown, ref, ...props }: NumberInputProps): import("react/jsx-runtime").JSX.Element;
