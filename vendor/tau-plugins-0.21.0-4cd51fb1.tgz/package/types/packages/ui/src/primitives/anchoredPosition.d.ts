/**
 * 浮层定位引擎（Tooltip / Select / Menu / Popover 共用，D-004；D-014 起更名
 * anchoredPosition——四家消费后不再顶着 tooltip 专名）——不依赖 React，可单独单测。
 * 中间件链：offset（间距默认 8）→ flip（主轴放不下翻对侧）→ shift（夹回视口，边距 8）→
 * arrow（锚点中心在边缘上的投影，两端各留 10px）。
 * 独立成文件：组件文件只导出组件（react-refresh 约束）。
 *
 * shift 的闸门：**锚点与视口不相交时完全不夹**。无条件夹会让锚点滚出视口后浮层
 * 被强行钉在视口边缘、与锚点脱钩——一屏多个离屏锚点就全挤在同一条边上。锚点
 * 离屏时让它自然跟随锚点离屏即可——几何上就不可见，无需额外的显示态管理。
 */
export type AnchoredSide = "top" | "right" | "bottom" | "left";
export type AnchoredAlign = "start" | "center" | "end";
export type AnchoredPlacement = AnchoredSide | `${AnchoredSide}-${AnchoredAlign}`;
/** 引擎可选参数：gap 覆写与锚点的间距（Select/Menu 下拉用 4，Tooltip/Popover 用默认 8）。 */
export interface AnchoredPositionOptions {
    gap?: number;
}
export interface AnchoredPosition {
    x: number;
    y: number;
    side: AnchoredSide;
    arrowX: number | null;
    arrowY: number | null;
}
/**
 * anchor 为触发器矩形；pop 只需要尺寸（jsdom 可用普通对象伪造）。
 */
export declare function computeAnchoredPosition(anchor: {
    left: number;
    top: number;
    right: number;
    bottom: number;
    width: number;
    height: number;
}, pop: {
    offsetWidth: number;
    offsetHeight: number;
}, placement: AnchoredPlacement, opts?: AnchoredPositionOptions): AnchoredPosition;
/**
 * 引擎投影值 → 箭头 inline 定位。箭头须为浮层的 firstElementChild（含箭头时）；
 * 每条边都显式写入（另一侧置 auto），side 翻转后不留上一姿态的残留。
 */
export declare function applyArrowPosition({ side, arrowX, arrowY }: AnchoredPosition, pop: HTMLElement): void;
