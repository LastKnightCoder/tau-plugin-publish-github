/**
 * Tooltip 基础件 —— Portal + 自研 JS mini 定位引擎（选型与排除记录见 D-004）。
 *
 * Portal（body 追加 fixed 元素）+ 自研 mini 定位引擎（D-004；定位生命周期收口
 * useAnchoredPosition，箭头复用 FloatingArrow——D-014 四家共用底盘），中间件链：
 * offset（间距 8）→ flip（主轴放不下翻对侧）→ shift（交叉轴夹回视口，边距 8）→
 * arrow（锚点中心在边缘上的投影，两端各留 10px）。
 *
 * 行为内建（不做成 props）：hover intent（450ms 进入 / 移出即隐 / 400ms 内重开免延迟——
 * 相邻触发器快速扫过不重复等待）；focus-visible 显示；aria-describedby 自动接线；
 * disabled 子元素自动包 wrapper（pointer 事件被吞）；锚点位置变化时 rAF 跟随（动态锚，
 * 如趋势图 hover 热区随鼠标移动）；scroll(capture)/resize 重算。
 * 反相配色复用 bg-ink-1 / text-ink-inverse（深浅主题各自反相，对比度由 token 保障）。
 * 不接 Esc、不进浮层退场注册表（瞬态非阻断，同 Toast 的 D-003 口径）；
 * 不承载可交互内容——可点的说明浮层是 Popover/Menu 的职责。
 */
import { type ReactElement, type ReactNode } from "react";
import { type AnchoredAlign, type AnchoredPlacement, type AnchoredSide } from "./anchoredPosition";
/** 引擎类型的历史名（D-004 起对外暴露；D-014 引擎更名后保留别名，存量引用不动） */
export type TooltipPlacement = AnchoredPlacement;
export type TooltipSide = AnchoredSide;
export type TooltipAlign = AnchoredAlign;
export interface TooltipProps {
    content: ReactNode;
    placement?: TooltipPlacement;
    /** 箭头（默认开；8px 菱形，尖端单角 2.5px 圆角，随 flip 自动换边） */
    arrow?: boolean;
    /** 显示延迟毫秒（默认 450；400ms 内重开免延迟） */
    delay?: number;
    /** 暂停提示并清理内部打开状态与延迟；优先于 open，不影响子元素交互。 */
    disabled?: boolean;
    /** 受控模式（对齐 §5.3 浮层 open 契约）：传入后组件不再做 hover intent，由调用方管理 */
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    /** 触发器（克隆注入事件与 aria-describedby；disabled 元素自动包 wrapper） */
    children: ReactElement;
    /** 浮层追加类名（经 cn 合并，可覆盖层级等默认值，如编辑器悬浮工具条之上的 z-[10110]） */
    className?: string;
}
export declare function Tooltip({ content, placement, arrow, delay, disabled, open: openProp, onOpenChange, children, className, }: TooltipProps): import("react/jsx-runtime").JSX.Element | null;
