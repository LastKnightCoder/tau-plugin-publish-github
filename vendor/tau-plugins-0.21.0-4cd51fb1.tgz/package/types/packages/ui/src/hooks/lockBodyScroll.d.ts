export declare function lockBodyScroll(owner: Document): () => void;
