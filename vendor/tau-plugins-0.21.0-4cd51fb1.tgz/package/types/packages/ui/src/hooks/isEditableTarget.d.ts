/** 键盘操作让位输入框、文本域和可编辑节点。 */
export declare function isEditableTarget(target: EventTarget | null): boolean;
