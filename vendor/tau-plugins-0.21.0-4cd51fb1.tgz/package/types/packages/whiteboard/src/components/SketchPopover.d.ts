import type { BoardElement } from "../types/element";
import type { PageSketch, SketchFillStyle, SketchLevel, SketchMode } from "../types/sketch";
type ModeChoice = SketchMode | "inherit";
export declare const randomSeed: () => number;
export declare const isPaintedFill: (color?: string) => boolean;
interface SketchFieldsProps {
    page: PageSketch;
    /** 当前画风选项；多选不一致时为 null（不高亮） */
    mode: ModeChoice | null;
    level: SketchLevel | null;
    levelFollowsPage: boolean;
    /** 是否有元素生效为手绘：决定是否展示笔触 / 填充 / 换一笔 */
    enabled: boolean;
    seed: number;
    fill?: {
        color: string;
        style: SketchFillStyle | null;
    };
    onMode: (v: ModeChoice) => void;
    onLevel: (v: SketchLevel) => void;
    onFillStyle: (v: SketchFillStyle) => void;
    onReseed: () => void;
    hint?: string;
}
/** 单选与多选共用的「笔触」弹层内容 */
export declare function SketchFields(props: SketchFieldsProps): import("react/jsx-runtime").JSX.Element;
interface SketchPopoverProps<T extends BoardElement> {
    /** 存覆盖的元素：一般是选中元素本身，思维导图是根节点 */
    target: T;
    onChange: (next: T) => void;
    /** 形状才有：填充样式（有填充色时显示） */
    fill?: {
        color?: string;
        style?: SketchFillStyle;
        onChange: (style: SketchFillStyle) => void;
    };
}
/**
 * 元素级「笔触」（D-107）：画风（跟随页面 / 手绘 / 普通）· 笔触档位 · 填充 · 换一笔。
 * 未单独设置的字段跟随页面，选「跟随页面」即删除覆盖。
 */
declare function SketchPopover<T extends BoardElement>({ target, onChange, fill }: SketchPopoverProps<T>): import("react/jsx-runtime").JSX.Element;
export default SketchPopover;
