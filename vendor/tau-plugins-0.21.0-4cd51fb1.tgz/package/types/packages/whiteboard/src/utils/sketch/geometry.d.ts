export type Vec = [number, number];
export interface Polyline {
    points: Vec[];
    closed: boolean;
}
export declare const distance: (a: Vec, b: Vec) => number;
export declare const clamp: (value: number, min: number, max: number) => number;
export declare function lengthOf(points: Vec[]): number;
export declare const polylineToD: (points: Vec[], closed?: boolean) => string;
/** 按弧长等距重采样，首尾点保留 */
export declare function resample(points: Vec[], step: number): Vec[];
/**
 * 沿法线方向的低频摆动：两段正弦按弧长叠加，相位由 random 决定。
 * 摆动是弧长的连续函数，端点移动时线形连续变化，不会整体跳变。
 * waveScale 缩放波长：尺寸很小的图形（火柴人等）传 <1，否则一整笔都落在半个波长内、看不出手抖。
 */
export declare function wobble(points: Vec[], amplitude: number, random: () => number, waveScale?: number): Vec[];
/**
 * SVG path d → 折线（每个子路径一条），支持 M/L/H/V/C/S/Q/T/A/Z 的绝对与相对形式。
 * 白板里的几何轮廓与连线路径（ArrowUtil.getArrowPath）都只用到这些命令。
 */
export declare function flattenPath(d: string): Polyline[];
