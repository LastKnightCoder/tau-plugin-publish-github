import { type Vec } from "./geometry";
export interface InkOptions {
    /** 起笔 / 收笔渐细长度（px），0 为平头 */
    taperStart?: number;
    taperEnd?: number;
    thinning?: number;
    streamline?: number;
}
/**
 * 一笔墨迹的轮廓（填充多边形）：起笔略重、行笔饱满、收笔变细，压力带极小噪声。
 * size 为墨迹最大宽度。
 */
export declare function inkOutline(points: Vec[], size: number, random: () => number, options?: InkOptions): string;
