import type { WhiteboardAPI } from "./api";
export declare const WhiteboardAPIContext: import("react").Context<WhiteboardAPI | null>;
export declare const WhiteboardAPIProvider: import("react").Provider<WhiteboardAPI | null>;
export declare function useWhiteboardAPI(): WhiteboardAPI;
