import type { Descendant } from "slate";
import type { MarkdownTextRegistry } from "./textCodec";
import { PositionMapper } from "./positionMapper";
import type { CustomDirectiveHandler, MarkdownCodec } from "./codec";
export interface SlateWithPositions {
    content: Descendant[];
    positionMap: PositionMapper;
}
export interface ImportFromMarkdownOptions {
    /** 宿主注册的业务 directive（container / leaf / text 三种都查），优先于内置分支 */
    customDirectives?: Record<string, CustomDirectiveHandler>;
}
/** 处理器级配置：宿主 codec 合并后的结果（框架不自带任何元素类型） */
export interface ImportConfig {
    textRegistry: MarkdownTextRegistry;
    directives: Record<string, CustomDirectiveHandler>;
    voidTypes: ReadonlySet<string>;
    inlineWrapperDirectives: ReadonlySet<string>;
    inlineHtmlWrappers?: ReadonlyMap<string, NonNullable<MarkdownCodec["inlineHtmlWrapper"]>>;
    fenceByLanguage: ReadonlyMap<string, {
        type: string;
        property: string;
    }>;
    importNodes?: readonly NonNullable<MarkdownCodec["importNode"]>[];
    fenceSourceProperties?: ReadonlyMap<string, string>;
    normalizeHooks?: ReadonlyMap<string, NonNullable<MarkdownCodec["normalize"]>>;
    inlineForms?: ReadonlyMap<string, NonNullable<MarkdownCodec["inlineForm"]>>;
}
/**
 * Markdown 导入（带位置映射）
 */
export declare const importFromMarkdownWithPositionsUsing: (config: ImportConfig, markdown: string, ignoreTypes?: string[], options?: ImportFromMarkdownOptions) => SlateWithPositions;
export declare const importFromMarkdownUsing: (config: ImportConfig, markdown: string, ignoreTypes?: string[], options?: ImportFromMarkdownOptions) => Descendant[];
/** 粗判一段纯文本是否像 Markdown（粘贴时决定要不要按 Markdown 导入） */
export declare const isMarkdownLikeText: (text: string) => boolean;
