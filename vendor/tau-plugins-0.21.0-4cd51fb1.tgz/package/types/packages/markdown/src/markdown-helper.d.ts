import type { Descendant } from "slate";
import type { CustomElement } from "./types";
import type { MarkdownSerializerRegistry } from "./markdownSerializerRegistry";
import { PositionMapper } from "./positionMapper";
import type { MarkdownTextRegistry } from "./textCodec";
/** 处理器级导出配置：注册表 + void 类型表 + 子元素接续表（内置 + 宿主 codec） */
export interface ExportConfig {
    textRegistry: MarkdownTextRegistry;
    registry: MarkdownSerializerRegistry;
    voidTypes: ReadonlySet<string>;
    /** 元素类型的子块级接续符（列表 / 表格为 "\n"，缺省 "\n\n"） */
    childSeparators: ReadonlyMap<string, "\n" | "\n\n">;
}
/** codec 的序列化器登记脚注（如 annotation 的 [^n]），由导出入口统一追加到文末 */
export declare const addExportFootnote: (content: string) => number;
export declare const getMarkdownUsing: (config: ExportConfig, value: Descendant[]) => string;
export declare const elementToMarkdownUsing: (config: ExportConfig, element: CustomElement, parentElement: CustomElement | null) => string;
/**
 * 带位置信息的 Markdown 输出
 */
export interface MarkdownWithPositions {
    markdown: string;
    positionMap: PositionMapper;
}
/**
 * 带位置跟踪的序列化函数（重新设计）
 */
export declare const getMarkdownWithPositionsUsing: (config: ExportConfig, value: Descendant[]) => MarkdownWithPositions;
