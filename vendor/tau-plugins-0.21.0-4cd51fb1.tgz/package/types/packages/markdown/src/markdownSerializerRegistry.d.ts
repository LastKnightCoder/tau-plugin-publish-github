import type { CustomElement } from "./types";
export interface SerializerOutput {
    output: string;
    childrenStart?: {
        line: number;
        ch: number;
    };
    perLineOffset?: number;
    childLineShifts?: Array<{
        startIndex: number;
        lineDelta: number;
    }>;
    skipChildren?: boolean;
    propertyMappings?: {
        [propName: string]: {
            start: {
                line: number;
                ch: number;
            };
            multiline: boolean;
        };
    };
}
export interface MarkdownSerializer {
    type: string;
    isBlock?: boolean;
    toMarkdown: (element: any, childrenStr: string, parentElement?: any) => string;
    toMarkdownStructured?: (element: any, childrenStr: string, parentElement?: any) => SerializerOutput;
}
/**
 * 导出端序列化器注册表：元素类型 → Markdown 文本的唯一出处。
 * 框架不自带任何序列化器，全部经 createMarkdownProcessor({ codecs }) 注入（各扩展的 markdown.ts）。
 */
export declare class MarkdownSerializerRegistry {
    private serializers;
    private blockTypes;
    private footnoteCounter;
    private footnoteDefinitions;
    constructor(serializers?: MarkdownSerializer[]);
    resetFootnotes(): void;
    addFootnote(content: string): number;
    getFootnoteDefinitions(): string;
    register(serializer: MarkdownSerializer): void;
    registerMany(serializers: MarkdownSerializer[]): void;
    getSerializer(type: string): MarkdownSerializer | undefined;
    isBlock(element: CustomElement): boolean;
}
