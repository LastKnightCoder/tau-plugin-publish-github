import type { InlineSourceRuntime } from "../../editor/source-contracts";
export type { InlineSourceRuntime } from "../../editor/source-contracts";
export declare function configureInlineSource(value: InlineSourceRuntime): void;
export declare const useInlineSource: InlineSourceRuntime["useInlineSource"];
export declare const insertInlineSource: InlineSourceRuntime["insertInlineSource"];
export declare const InlineSourceBoundary: InlineSourceRuntime["InlineSourceBoundary"];
