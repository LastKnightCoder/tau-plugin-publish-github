import type { Disposable } from "./contract";
import type { JsonValue } from "./json";
export type PluginMCPTransport = {
    type: "stdio";
    command: string;
    args?: string[];
    env?: Record<string, string>;
    cwd?: string;
} | {
    type: "streamable-http";
    url: string;
    headers?: Record<string, string>;
};
export interface PluginMCPToolResult {
    content: string;
    render?: {
        version: number;
        data: JsonValue;
    };
}
export interface PluginMCPTool {
    name: string;
    description: string;
    inputSchema: {
        type: "object";
        properties?: Record<string, JsonValue>;
        [key: string]: JsonValue | undefined;
    };
    execute(args: Record<string, JsonValue>, context: {
        signal: AbortSignal;
    }): Promise<PluginMCPToolResult> | PluginMCPToolResult;
}
export type PluginMCPDefinition = {
    id: string;
    name: string;
    description?: string;
} & ({
    tools: readonly PluginMCPTool[];
    transport?: never;
} | {
    transport: PluginMCPTransport;
    tools?: never;
});
export interface PluginMCP {
    /** 同一插件可注册多个 MCP；停用时由宿主自动回收。 */
    register(definition: PluginMCPDefinition): Disposable;
}
export declare function snapshotMCPToolResult(result: PluginMCPToolResult): PluginMCPToolResult;
export declare function snapshotMCPDefinition(definition: PluginMCPDefinition): PluginMCPDefinition;
