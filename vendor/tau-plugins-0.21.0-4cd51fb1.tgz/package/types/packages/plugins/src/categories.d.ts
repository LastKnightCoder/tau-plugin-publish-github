/** 插件中心分类按扩展点划分，顺序即展示顺序；新增面向用户的扩展点时同步扩充。 */
export declare const PLUGIN_CATEGORIES: readonly [{
    readonly id: "sync";
    readonly label: "同步";
}, {
    readonly id: "upload";
    readonly label: "资源上传";
}, {
    readonly id: "editor";
    readonly label: "编辑器";
}, {
    readonly id: "whiteboard";
    readonly label: "白板";
}, {
    readonly id: "blog-template";
    readonly label: "博客模板";
}, {
    readonly id: "blog-publish";
    readonly label: "博客发布";
}, {
    readonly id: "ai";
    readonly label: "AI";
}, {
    readonly id: "voice";
    readonly label: "语音";
}, {
    readonly id: "page";
    readonly label: "页面";
}];
export type PluginCategory = (typeof PLUGIN_CATEGORIES)[number]["id"];
export declare const PLUGIN_KEYWORD_LIMIT = 5;
export declare const PLUGIN_KEYWORD_MAX_LENGTH = 20;
export declare const isPluginCategory: (value: unknown) => value is PluginCategory;
export interface PluginCatalogFields {
    categories?: readonly PluginCategory[];
    keywords?: readonly string[];
}
/**
 * 读取 manifest 中的分类与关键词。
 * strict 用于门户上传，非法值直接报错；客户端用宽松模式静默丢弃，
 * 使老客户端不会因词表新增或上限调整而拒收插件。
 */
export declare function readCatalogFields(item: Record<string, unknown>, strict: boolean): PluginCatalogFields;
