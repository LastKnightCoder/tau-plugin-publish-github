export declare function comparePluginVersions(left: string, right: string): number;
export declare function assertPluginCompatibility(manifest: {
    minAppVersion?: string;
}, clientVersion: string): void;
