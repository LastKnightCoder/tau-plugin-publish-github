export { assertLocalId } from "./ids";
import { type PluginCategory } from "./categories";
export { comparePluginVersions } from "./version";
export { PLUGIN_CATEGORIES, PLUGIN_KEYWORD_LIMIT, PLUGIN_KEYWORD_MAX_LENGTH, isPluginCategory, type PluginCategory, } from "./categories";
export declare const PLUGIN_SHARED_MODULES: readonly ["@tau/plugins", "@tau/plugins/whiteboard", "@tau/plugins/sync", "@tau/ui", "react", "react-dom", "react-dom/client", "react/jsx-runtime", "react/jsx-dev-runtime"];
export interface PluginManifest {
    formatVersion: 1;
    id: string;
    name: string;
    version: string;
    minAppVersion?: string;
    apiVersion: 1;
    platform: "desktop";
    format: "cjs";
    main: string;
    /** 无界面的同步存储入口，Node产物与UI入口分别校验。 */
    styles?: string;
    /** 静态编辑器贡献在窗口启动时装配，启停需重启。 */
    editor?: true;
    whiteboard?: true;
    /** 插件中心分类，作者自填，不与实际注册对账。 */
    categories?: readonly PluginCategory[];
    /** 仅参与搜索匹配。 */
    keywords?: readonly string[];
    integrity: Record<string, string>;
}
/** 宿主内部传输的已读取产物，不属于作者运行时 API。 */
export interface DevelopmentPluginPackage {
    manifest: PluginManifest;
    code: string;
    css?: string;
}
/** strict 供门户上传使用：分类或关键词不合规时报错，客户端默认静默丢弃。 */
export declare function validatePluginManifest(value: unknown, options?: {
    strict?: boolean;
}): PluginManifest;
/** 静态内容贡献在启动时固定，启停与更新需要重启。 */
export declare const isContentPlugin: (manifest: Pick<PluginManifest, "editor" | "whiteboard">) => boolean;
