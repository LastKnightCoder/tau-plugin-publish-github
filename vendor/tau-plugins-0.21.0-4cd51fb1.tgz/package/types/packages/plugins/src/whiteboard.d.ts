export { defineElement, defineWhiteboardExtension, useWhiteboardAPI, useSketch, usePageSketch, AttrPopover, AttrToggle, OptionGrid, Seg, SketchPopover, sketch, SketchPaths, } from "../../whiteboard/src/author";
export type { SketchPath, Vec } from "../../whiteboard/src/author";
export type { SchematicShape, SchematicFill, ResolvedSketch, ElementSketch, PageSketch, SketchLevel, } from "../../whiteboard/src/author";
export type { WhiteboardAPI, WhiteboardExtension, WhiteboardElementDefinition, WhiteboardContributions, TypedBoardElement, ElementCreateSpec, WhiteboardSnapshot, BoardElement, WhiteboardToolProps, } from "../../whiteboard/src/author";
import type { PluginStorage } from "./contract";
/** 由宿主按插件和工作区绑定，交互扩展通过 requires 声明后获取。 */
export declare const IPluginStorage: import("../../shared/service-contract").ServiceIdentifier<PluginStorage>;
