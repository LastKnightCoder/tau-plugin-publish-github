import type { ComponentType } from "react";
import type { Disposable, PluginContext } from "./index";
export type PluginPageParams = Record<string, string | number | boolean>;
export interface PluginPageProps {
    readonly context: PluginContext;
    readonly params: Readonly<PluginPageParams>;
}
export interface PluginPageDefinition {
    id: string;
    title: string;
    component: ComponentType<PluginPageProps>;
    match?: "single" | "params";
    /** params 页缺省按完整参数区分实例；提供时只按该身份去重。 */
    getId?(params: Readonly<PluginPageParams>): string;
}
export interface PluginPageHandle extends Disposable {
    readonly id: string;
    open(params?: PluginPageParams): Promise<void>;
}
export interface PluginPages {
    register(definition: PluginPageDefinition): PluginPageHandle;
}
export declare function normalizePageParams(value: unknown): PluginPageParams;
