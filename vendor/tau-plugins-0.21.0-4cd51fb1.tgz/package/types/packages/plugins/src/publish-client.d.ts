import type { DataClient } from "./publish-data";
export declare class DataError extends Error {
    code: string;
    constructor(code: string, message: string);
}
export declare function createClient({ manifestUrl }: {
    manifestUrl: string;
}): DataClient;
