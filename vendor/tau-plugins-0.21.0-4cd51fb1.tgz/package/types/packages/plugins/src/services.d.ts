import type { Descendant } from "slate";
import type { MarkdownCodec } from "../../markdown/src/index";
import type { GitSnapshotRequest, GitCacheDirectory } from "./publish";
export type { Descendant } from "slate";
export interface ServiceOptions {
    signal?: AbortSignal;
}
export interface ServiceWarning {
    code: string;
    message: string;
    path?: number[];
}
export interface ServiceFile {
    /** 任务内的相对文件名，不是宿主文件路径。 */
    name: string;
    data: Blob;
}
export interface MarkdownServiceOptions extends ServiceOptions {
    /** 仅参与本次转换，不修改全局编辑器。 */
    codecs?: readonly MarkdownCodec[];
}
export interface MediaProgress {
    /** 已处理的媒体时间，单位秒；不推测总时长或百分比。 */
    time: number;
}
export interface MediaInfo {
    format: {
        name: string;
        duration: number | null;
        size: number | null;
    };
    streams: {
        index: number;
        type: string;
        codec: string;
        width?: number;
        height?: number;
        sampleRate?: number;
        channels?: number;
    }[];
}
export interface PluginServices {
    git: {
        publishSnapshot(input: GitSnapshotRequest, options?: ServiceOptions): Promise<void>;
        selectCacheDirectory(input: Record<string, never>, options?: ServiceOptions): Promise<GitCacheDirectory | null>;
    };
    tailwind: {
        compile(input: {
            source: string;
            language?: "html" | "tsx" | "jsx";
        }, options?: ServiceOptions): Promise<{
            css: string;
        }>;
    };
    typst: {
        compile(input: {
            source: string;
            format?: "html";
            inputs?: Record<string, string>;
            files?: ServiceFile[];
        }, options?: ServiceOptions): Promise<{
            html: string;
        }>;
    };
    markdown: {
        deserialize(source: string, options?: MarkdownServiceOptions): Promise<{
            nodes: Descendant[];
            warnings: ServiceWarning[];
        }>;
        serialize(nodes: Descendant[], options?: MarkdownServiceOptions): Promise<{
            markdown: string;
            warnings: ServiceWarning[];
        }>;
        render(source: string, options?: MarkdownServiceOptions & {
            theme?: "light" | "dark";
        }): Promise<{
            html: string;
            css: string;
            warnings: ServiceWarning[];
        }>;
    };
    ffmpeg: {
        probe(input: ServiceFile, options?: ServiceOptions): Promise<MediaInfo>;
        /** args 中用任务文件名引用输入和输出；不接受 shell 命令。 */
        run(input: {
            files: ServiceFile[];
            args: string[];
            outputs: {
                name: string;
                mimeType: string;
            }[];
        }, options?: ServiceOptions & {
            onProgress?: (progress: MediaProgress) => void;
        }): Promise<{
            files: ServiceFile[];
            log: string;
        }>;
    };
}
/** 每个调用同时受调用方与插件实例生命周期约束。 */
export declare function bindPluginServices(adapter: PluginServices | undefined, lifetime: AbortSignal, assertActive: () => void): PluginServices;
