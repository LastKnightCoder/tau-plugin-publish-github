import { Editor, NodeEntry } from "slate";
export declare const exitContainerOnEmptyParagraph: (editor: Editor, parentType: string) => boolean;
export declare const hitEmptyOrInlineChild: (editor: Editor, [node, path]: NodeEntry, parentType: string) => boolean;
