import type { ReactNode } from "react";
import type { LucideIcon } from "lucide-react";
/**
 * 块右上角的悬浮操作条（代码块、源码预览块共用）：浅色实底 + 描边 + 浮起投影，随主题。
 * 显隐交给调用方的 group-hover 类（Tailwind 需要静态类名），例如
 * `group-hover/code:pointer-events-auto group-hover/code:translate-y-0 group-hover/code:opacity-100`。
 * 定位取 min(右上角, 垂直居中)：块较矮（如单行）时居中，较高时贴右上角。
 */
export declare const FloatingToolbar: ({ className, children, }: {
    className?: string;
    children: ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
export declare const ToolbarDivider: () => import("react/jsx-runtime").JSX.Element;
export declare const ToolbarIconButton: ({ icon: Icon, title, onClick, disabled, tone, active, className, }: {
    icon: LucideIcon;
    title: string;
    onClick?: () => void;
    disabled?: boolean;
    tone?: "default" | "danger" | "ok";
    /** 按下态（开关类按钮） */
    active?: boolean;
    className?: string;
}) => import("react/jsx-runtime").JSX.Element;
