import { Editor, Element as SlateElement, NodeEntry, Path } from "slate";
import type { ElementSpec } from "../api/extension";
export declare const registerBlockNavigationBoundaries: (editor: Editor, elements: readonly ElementSpec[]) => void;
export type BlockFocusPosition = "start" | "end";
export type BlockNavigationReason = "delete" | "arrow" | "enter";
export type BlockNavigationDirection = "backward" | "forward";
export interface BlockNavigationMeta {
    reason: BlockNavigationReason;
    direction: BlockNavigationDirection;
}
export interface BlockFocusContext {
    editor: Editor;
    element: SlateElement;
    meta: BlockNavigationMeta;
}
export type BlockFocusHandler = (context: BlockFocusContext) => boolean;
export interface BlockNavigationHandler {
    focusStart?: BlockFocusHandler;
    focusEnd?: BlockFocusHandler;
}
export declare const registerBlockNavigation: (element: SlateElement, handler: BlockNavigationHandler) => void;
export declare const unregisterBlockNavigation: (element: SlateElement) => void;
export declare const hasBlockNavigation: (element: SlateElement) => boolean;
export declare const focusElementByNavigator: (editor: Editor, element: SlateElement, position: BlockFocusPosition, meta: BlockNavigationMeta) => boolean;
export declare const getSiblingBlockEntry: (editor: Editor, fromPath: Path, direction: BlockNavigationDirection) => NodeEntry<import("../../../api").ParagraphElement> | undefined;
export declare const focusPreviousBlock: (editor: Editor, fromPath: Path, meta: BlockNavigationMeta) => boolean;
export declare const focusNextBlock: (editor: Editor, fromPath: Path, meta: BlockNavigationMeta) => boolean;
export declare const hasBlockNavigationBoundary: (editor: Editor, path: Path) => boolean;
