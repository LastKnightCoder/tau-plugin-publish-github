import type { ReactNode } from "react";
import { type EditorThemeMode, type ThemeService } from "./ThemeService";
/** 宿主用：让子树里的编辑器按给定明暗 / 主题族渲染，不跟随宿主；缺省的维度不覆盖 */
export declare function EditorThemeOverride({ mode, themeKey, children, }: {
    mode?: EditorThemeMode;
    themeKey?: string;
    children: ReactNode;
}): import("react/jsx-runtime").JSX.Element;
/** 编辑器内部用：确定本编辑器的主题服务，并告知根节点是否要补作用域属性 */
export declare function EditorThemeScope({ service, children, }: {
    /** 服务注册表里的 IThemeService；上下文里有服务时以上下文为准 */
    service?: ThemeService;
    children: (scope: {
        themeKey: string;
        mode: EditorThemeMode;
        overridden: boolean;
    }) => ReactNode;
}): import("react/jsx-runtime").JSX.Element;
export interface EditorTheme {
    mode: EditorThemeMode;
    isDark: boolean;
    /** 读取 token 实际取值，给 mermaid / shiki / canvas 这类需要色值的渲染器用 */
    token: (word: string) => string;
}
/** 编辑器内部读主题：明暗 + token 取值。未挂载 Editor 时回落 DOM 实现。 */
export declare function useEditorTheme(): EditorTheme;
