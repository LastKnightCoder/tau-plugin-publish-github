import React from "react";
export type HoveringSubmenuTrigger = "hover" | "click";
export interface IHoveringBarContext {
    isHoveringBarShow: boolean;
    isCompact: boolean;
    submenuTrigger: HoveringSubmenuTrigger;
}
export declare const HoveringBarContext: React.Context<IHoveringBarContext>;
