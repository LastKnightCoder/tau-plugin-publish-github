import React from "react";
import type { HoveringSubmenuTrigger } from "./context";
import { type FloatingPlacement } from "./floatingPosition";
interface FloatingSubmenuProps {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    trigger: HoveringSubmenuTrigger;
    isHoveringBarShow: boolean;
    children: React.ReactNode;
    content: React.ReactNode;
    preferredPlacement?: FloatingPlacement;
    gap?: number;
    zIndex?: number;
    triggerClassName?: string;
    panelClassName?: string;
    panelStyle?: React.CSSProperties;
}
declare const FloatingSubmenu: (props: FloatingSubmenuProps) => import("react/jsx-runtime").JSX.Element;
export default FloatingSubmenu;
