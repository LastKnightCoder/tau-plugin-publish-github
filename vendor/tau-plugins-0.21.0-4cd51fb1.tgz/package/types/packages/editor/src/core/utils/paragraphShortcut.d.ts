import { Editor, type NodeEntry } from "slate";
import type { FormattedText } from "../types/text";
/** 空格触发的段落快捷语法只读取段落首个文本节点，语法判断由扩展负责。 */
export declare function getParagraphShortcutEntry(editor: Editor, text: string): NodeEntry<FormattedText> | undefined;
