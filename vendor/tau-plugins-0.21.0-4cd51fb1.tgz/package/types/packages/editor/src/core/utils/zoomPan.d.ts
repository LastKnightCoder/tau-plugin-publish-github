export interface Point {
    x: number;
    y: number;
}
/**
 * 以某点为锚缩放时的新平移量：锚点下的内容保持不动。
 * 坐标都相对舞台中心，内容以 `translate(pan) scale(zoom)` 摆放、变换原点在中心。
 */
export declare const panAroundAnchor: (pan: Point, zoom: number, nextZoom: number, anchor: Point) => Point;
/** 指针事件相对元素中心的坐标 */
export declare const pointFromCenter: (element: HTMLElement, event: {
    clientX: number;
    clientY: number;
}) => Point;
