import React from "react";
import type { Element } from "slate";
interface IAddParagraphProps {
    element: Element;
    onAddParagraph?: () => void;
}
export interface AddParagraphRef {
    addParagraph: () => void;
}
declare const AddParagraph: React.ForwardRefExoticComponent<IAddParagraphProps & React.RefAttributes<AddParagraphRef>>;
export default AddParagraph;
