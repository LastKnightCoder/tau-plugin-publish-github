import type { Element } from "slate";
export interface ElementMenuProps {
    element: Element;
    position: {
        x: number;
        y: number;
    };
    onClose: () => void;
}
/** 在指定位置打开目标元素已注册的菜单，不接受绕过命令协议的条目。 */
export default function ElementMenu({ element, position, onClose }: ElementMenuProps): import("react/jsx-runtime").JSX.Element;
