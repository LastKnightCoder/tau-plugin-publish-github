import type { Editor } from "slate";
import { type EditorNotifier } from "./notifier";
/** 提示服务按编辑器绑定；服务派生后继续读取当前作用域。 */
export declare function notifierOf(editor: Editor): EditorNotifier;
