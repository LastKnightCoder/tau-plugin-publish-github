import { Editor, Element, Path, type BaseRange } from "slate";
import type { ServiceIdentifier } from "../services/tokens";
interface SubmissionOptions {
    signal?: AbortSignal;
    /** 只跟踪本操作依赖的服务；无关主题或插槽派生不取消操作。 */
    services?: readonly ServiceIdentifier<unknown>[];
}
export type SubmissionDiscardReason = "cancelled" | "scope-ended" | "readonly" | "target-lost" | "target-changed";
export type SubmissionOutcome = {
    status: "committed";
} | {
    status: "discarded";
    reason: SubmissionDiscardReason;
};
export interface Submission<T> {
    readonly signal: AbortSignal;
    /** 失效时终结操作并释放引用；不能放进要求纯判断的表单 validate。 */
    check(): SubmissionDiscardReason | undefined;
    /** 只提交一次；回调必须同步，异常向上传播，不能依赖事务回滚。 */
    commit(write: (target: T) => undefined): SubmissionOutcome;
    dispose(): void;
}
/** 无元素目标的输入请求只绑定编辑会话和调用方取消信号。 */
export declare const captureEditorSubmission: (editor: Editor, options?: SubmissionOptions) => Submission<void>;
export declare function captureElementSubmission<E extends Element>(editor: Editor, options: SubmissionOptions & {
    element: E;
    path?: Path;
    accept?: (current: E) => boolean;
}): Submission<{
    element: E;
    path: Path;
}>;
/** 段落内的原始折叠落点；后续选区变化不会改写该落点。 */
export declare function captureInsertionSubmission(editor: Editor, signal?: AbortSignal): Submission<{
    range: BaseRange;
    path: Path;
}>;
export {};
