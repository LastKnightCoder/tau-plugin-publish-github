import { type ThemeMode } from "./defineTheme";
import "./register";
/** 明暗偏好：固定浅色 / 固定深色 / 跟随系统（与主题族正交） */
export type Appearance = ThemeMode | "system";
export declare const DEFAULT_THEME_KEY = "paper";
export declare const DEFAULT_APPEARANCE: Appearance;
export declare const THEME_STORAGE_KEY = "tau-theme";
export declare const APPEARANCE_STORAGE_KEY = "tau-appearance";
export interface ThemeRuntimeConfig {
    defaultTheme: string;
    defaultAppearance: Appearance;
    themeStorageKey: string;
    appearanceStorageKey: string;
    themes: string[];
}
export interface ResolvedThemePreference {
    theme: string;
    appearance: Appearance;
    mode: ThemeMode;
}
export declare function themeRuntimeConfig(overrides?: Partial<Omit<ThemeRuntimeConfig, "themes">>): ThemeRuntimeConfig;
/**
 * 存储值 → 生效主题。首帧内联脚本经 toString() 内嵌本函数，必须自包含（不引用模块内其它符号）。
 */
export declare function resolveThemePreference(savedTheme: string | null, savedAppearance: string | null, prefersDark: boolean, config: ThemeRuntimeConfig): ResolvedThemePreference;
export declare function createThemeBootstrapScript(config?: ThemeRuntimeConfig): string;
