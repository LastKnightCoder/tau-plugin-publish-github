/**
 * 主题「樱花」—— 樱粉纸底 + 梅褐墨 + 莓粉 accent，温柔明亮。
 *
 * 浅色（晴）：纸底粉调强度对齐暖纸的暖调；accent 受 AA 所限明度不能高，粉感靠高饱和
 * （62%）撑起，选中 / soft 底透明度也提一档让粉色在界面里可见；danger 偏橙红，与莓粉拉开。
 * 深色（夜樱）：夜底带一层梅粉调（可辨但不整页泛粉）+ 樱白墨 + 高饱和莓粉 accent。
 *
 * 对比度按 02 规范 §2.5，深浅两套均由 theme-parity.test.ts 校验。
 */
declare const _default: import("../defineTheme").ThemeDefinition;
export default _default;
