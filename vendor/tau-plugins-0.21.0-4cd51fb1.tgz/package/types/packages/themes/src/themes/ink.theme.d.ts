/**
 * 主题「水墨」—— 宣纸落墨：近白而非纯白、近黑而非纯黑，彩度压到最低，素净留白。
 *
 * 浅色（宣纸）：微暖米白纸底 + 浓墨；accent 取低饱和「青黛」（墨中带一丝蓝灰），仍是墨色却可辨识；
 * 状态色取国画颜料（石绿 / 藤黄 / 朱砂 / 花青 / 赭石）并全部降饱和；阴影比其它主题更淡，画面更平静。
 * 深色（松烟）：暖黑墨底 + 宣纸色墨字 + 提亮青黛；层级口径同暖纸 · 夜。
 *
 * 对比度按 02 规范 §2.5，深浅两套均由 theme-parity.test.ts 校验。
 */
declare const _default: import("../defineTheme").ThemeDefinition;
export default _default;
