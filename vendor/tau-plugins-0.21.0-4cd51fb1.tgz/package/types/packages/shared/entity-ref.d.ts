/**
 * 统一实体地址：跨模块指向「一份正文的某个身份」（卡片、文章、项目文档、日记）。
 *
 * 纯 TypeScript，桌面端与移动端共用。存量各处的类型写法（question_link 的 project_item、
 * content-link / 索引的 project-item）经 normalizeEntityRefKind 收口；
 * 日记正文身份为 diary-moment + 片段 id，存量日级引用在开库时转换。
 */
export declare const ENTITY_REF_KINDS: readonly ["card", "article", "project-item", "diary-moment"];
export type EntityRefKind = (typeof ENTITY_REF_KINDS)[number];
export interface EntityRef {
    kind: EntityRefKind;
    id: number;
}
/** 各处存量写法 → EntityRefKind；不认识的返回 null，由调用方丢弃 */
export declare function normalizeEntityRefKind(raw: unknown): EntityRefKind | null;
export declare const entityRefKey: (ref: EntityRef) => string;
export declare const isSameEntityRef: (a: EntityRef, b: EntityRef) => boolean;
/** 同一份正文被多个实体共用时，选哪个身份作代表：卡片 > 文章 > 项目文档 > 日记 */
export declare const ENTITY_REF_PRIORITY: Record<EntityRefKind, number>;
