# Tau 插件开发包 @tau/plugins

开发 Tau 插件所需的类型与接口，通过 npm 别名安装为 `@tau/plugins`。根入口的实际实现由 Tau 客户端提供，构建时需设为 external。plugins 包另提供独立站点可用的 publish-data 类型和 publish-client 纯数据客户端，见该包 PUBLISH-DATA.md；不包含站点渲染、路由或预览实现。

从模板开始开发：https://github.com/LastKnightCoder/tau-plugin-template

编译与转换服务见 [SERVICES.md](SERVICES.md)，编辑器扩展、源码预览与插件 Skill 见 [EDITOR.md](EDITOR.md)，需要 Tau 0.59.0 及以上。AI 功能声明、模型分配与用量审计见 [AI.md](AI.md)。
